import SwiftUI

struct Introduction: View {
    
    @State var currPage = 0
    @State var inputA = false
    @State var inputB = false
    @State var inputC = false
    @State var inputD = false
    @State var inputE = false
    @State var inputF = false
    let fontSize: CGFloat = 20
    let spacerDimension:CGFloat = 50
    let textWidth: CGFloat = 760
    let tipsBoxCornerRradius: CGFloat = 20
    let buttonHeight: CGFloat = 50
    let buttonWidth: CGFloat = 250
    let buttonCornerRadius: CGFloat = 25
    let tipsBoxColor = Color.mint
    let tipsBoxHeight: CGFloat = 150
    let outputTextColor = Color.pink
    let buttonColor = Color.orange
    let textColor = Color.black

    var body: some View {
        VStack {
            switch currPage {
            case 0:
                Text("Introduction")
                    .bold()
                    .font(.largeTitle)
                    .foregroundColor(textColor)
                

                Text("Hi, I’m Michele Impinto, 26 years old, born and raised in Naples 🇮🇹. Since childhood I have always been charmed from video games, computers and everything related to technology as they were magical and so I wanted to learn everything about that “magic”. Growing up I carried on my childhood dream firstly by my own in the free time until the end of high school and after studying informatics science at “Università degli studi di Napoli Federico II”, there I learned most of my knowledge about coding, algorithms, computational thinking, problem solving and etcetera, one of the aforementioned knowledges is boolean algebra, boolean algebra stands at the heart of computer science and that's why I build this playgroud, in fact this project aims to teach something about boolean algebra.")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .center)
            
                Spacer().frame(height: spacerDimension)
                
            Text("Boolean algebra")
                    .bold()
                    .font(.largeTitle)
                    .foregroundColor(textColor)

                    Text("In boolean algebra we consider every number as a bit, every bit can represent one of two possible values at a time, this values are named in various ways like '1' and '0', 'true' and 'false', 'on' and 'off', etc. Using the bits is possible to perform a wide set of operations, the basic operations of boolean algebra are the negation (NOT) denoted as '¬', conjunction (AND) denoted as '∧' and the disjunction (OR) denoted as '∨'. Starting from this three operations is possible to expand even further our set of operations (but we'll keep this for later 😉)")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .center)
                                
            Text("\nFor each boolean operation there is a graphical representation, called 'logic gate', as you can see below.")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .leading)
                
            HStack {
                Image(uiImage: UIImage(named: "NOT.png")!)
                Image(uiImage: UIImage(named: "AND.png")!)
                Image(uiImage: UIImage(named: "OR.png")!)
                Image(uiImage: UIImage(named: "XOR.png")!)
            }
            
            HStack {
                Image(uiImage: UIImage(named: "NAND.png")!)
                Image(uiImage: UIImage(named: "NOR.png")!)
                Image(uiImage: UIImage(named: "XNOR.png")!)
            }
            
                Spacer().frame(height: spacerDimension / 2)

                Text("\nNOTE: 1. In this playground we'll use the values 'true' and 'false' to set our variables\n2. Before starting, please rotate your device in portrait mode.")
                    .font(.system(size: fontSize))
                    .italic()
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .leading)
            case 1:
            Text("Logic gates and truth tables")
                    .bold()
                    .font(.largeTitle)
                    .foregroundColor(textColor)
                
            Text("For every operation there is a corresponding 'truth table'. In Boolean algebra, truth tables allow to represent a logical expression. In a truth table are represented in column all the possible combinations of the inputs and the corresponding output. Below you can see the truth tables referring to various boolean operations.")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .center)

                Spacer().frame(height: spacerDimension)

            Image(uiImage: UIImage(named: "Tabelle-di-verità.png")!)
            Image(uiImage: UIImage(named: "Tabelle-di-verità2.png")!)

                Spacer().frame(height: spacerDimension)

            Text("In the next pages we'll explore this operations, one at a time, so go to the next page when you're ready to learn everything about the NOT operation!")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    .frame(width: textWidth, height: .infinity, alignment: .center)
                
            Spacer().frame(height: spacerDimension)

            case 2:
                Text("The NOT logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)

                Text("The NOT operation takes truth to falsity and vice versa, furthermore is the only operation that requires only one parameter.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_NOT.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                            
                            Text("The NOT operation returns the value opposite to the input value. For example if you give as input TRUE the result will be FALSE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }

                Spacer().frame(height: spacerDimension / 2)

                Text("This page features a simple logical circuit with a NOT gate.\n1. Look at the output of the circuit.\n2. Try changing the value of A. What happens to the output?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                Spacer().frame(height: spacerDimension / 2)

                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }

                Spacer().frame(height: spacerDimension)
                
                HStack {
                    Image(uiImage: UIImage(named: "NOTconA.png")!)
                    
                    Text(String(!inputA))
                        .font(.system(size: fontSize * 1.5))
                        .foregroundColor(outputTextColor)
                }
                
                Text("Go to the next page where you will learn about the AND logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
            case 3:
                Text("The AND logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)

                Text("The AND operation returns the conjuction of the two inputs. You can see below the truth table for the AND logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_AND.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The AND operation returns TRUE only if both the inputs are TRUE. For example if you give as input TRUE and FALSE the return value will be FALSE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }
                
                Spacer().frame(height: spacerDimension / 2)
                
                Text("This page features two logical circuits.\n1. Look at the outputs of the circuits.\n2. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                        .font(.system(size: fontSize))
                        .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "ANDconAB.png")!)
                    
                    Text(String(inputA && inputB))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito2.png")!)
                    
                    Text(String(!inputA && inputB))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                Text("Go to the next page where you will learn about the OR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)

            case 4:
                Text("The OR logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)

                Text("The OR operation returns the disjuction of the two inputs. You can see below the truth table for the OR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_OR.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The OR operation returns TRUE if one of both the inputs are TRUE. For example if you give as input TRUE and FALSE the return value will be TRUE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }
                
                Spacer().frame(height: spacerDimension / 2)
                
                Text("This page features two logical circuits.\n1. Look at the outputs of the circuits.\n2. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                                        
                    Text("var C = " + String(inputC))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputC = !inputC
                    })
                    {
                        Text("Change the value of C")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "ORconAB.png")!)
                    
                    Text(String(inputA || inputB))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito3.png")!)
                    
                    VStack {
                        Text(String(!(inputA && (inputB || inputC))))
                            .font(.system(size: fontSize*1.5))
                            .foregroundColor(outputTextColor)
                        
                        Spacer().frame(height: 75)
                    }
                }
                
                Text("Go to the next page where you will learn about the XOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)

            case 5:
                Text("The XOR logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)

                Text("'XOR' stands for 'exclusive OR', this operation returns the exclusive disjuction of the two inputs. You can see below the truth table for the XOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_XOR.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The XOR operation returns TRUE if the inputs have different values. For example if you give as input TRUE and FALSE the return value will be TRUE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }
                
                Spacer().frame(height: spacerDimension / 2)
                
                Text("This page features two logical circuits.\n1. Look at the outputs of the circuits.\n2. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                }
                
                HStack {
                    Text("var C = " + String(inputC))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputC = !inputC
                    })
                    {
                        Text("Change the value of C")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var D = " + String(inputD))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputD = !inputD
                    })
                    {
                        Text("Change the value of D")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "XORconAB.png")!)
                    
                    Text(String(inputA != inputB))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito8.png")!)
                    
                    Text(String((inputC != false) && (inputD != true)))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                Text("Go to the next page where you will learn about the NAND logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
            case 6:
                Text("The NAND logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)
            
                Text("'NAND' stands for 'NOT AND' and in fact is the exact opposite of the AND operation that we saw earlier. You can see below the truth table for the NAND logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_NAND.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The NAND operation returns TRUE if at least one of the inputs is FALSE. For example if you give as input TRUE and FALSE the return value will be TRUE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }

                Text("This page features three logical circuits.\n1. Look at the outputs of the circuits.\n2. Bring particular attention to the two circuits on the top side, they will always share the output, why?\n3. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                }
                
                HStack {
                    Text("var E = " + String(inputE))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputE = !inputE
                    })
                    {
                        Text("Change the value of E")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Spacer().frame(width: spacerDimension / 2)

                    Text("var F = " + String(inputF))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputF = !inputF
                    })
                    {
                        Text("Change the value of F")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "NANDconAB.png")!)
                    
                    Text(String(!(inputA && inputB)))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    Image(uiImage: UIImage(named: "Circuito4.png")!)
                    
                    Text(String(!(inputA && inputB)))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito5.png")!)
                    
                    Text(String(!inputF || !inputE))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                Text("Go to the next page where you will learn about the NOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
            case 7:
                Text("The NOR logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)
            
                Text("'NOR' stands for 'NOT OR' and in fact is the exact opposite of the OR operation that we saw earlier. You can see below the truth table for the NOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_NOR.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The NOR operation returns TRUE only if both the inputs are FALSE. For example if you give as input TRUE and FALSE the return value will be FALSE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }
                
                Text("This page features three logical circuits.\n1. Look at the outputs of the circuits.\n2. Bring particular attention to the two circuits on the top side, they will always share the output, why?\n3. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                }
                
                HStack {
                    Text("var E = " + String(inputE))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputE = !inputE
                    })
                    {
                        Text("Change the value of E")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var F = " + String(inputF))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputF = !inputF
                    })
                    {
                        Text("Change the value of F")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "NORconAB.png")!)
                    
                    Text(String(!(inputA || inputB)))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    Image(uiImage: UIImage(named: "Circuito6.png")!)
                    
                    Text(String(!(inputA || inputB)))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito7.png")!)
                    
                    Text(String(!inputF && inputE))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                Text("Go to the next page where you will learn about the XNOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
            case 8:
                Text("The XNOR logic operation")
                .bold()
                .font(.largeTitle)
                .foregroundColor(textColor)
              
                Text("'XNOR' stands for 'NOT XOR' and in fact is the exact opposite of the XOR operation that we saw earlier. You can see below the truth table for the XNOR logic operation.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                
                HStack {
                    Image(uiImage: UIImage(named: "TDV_XNOR.png")!)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    ZStack {
                        tipsBoxColor
                            .frame(width: textWidth / 2, height: tipsBoxHeight, alignment: .center)
                            .cornerRadius(tipsBoxCornerRradius)
                        VStack {
                            Text("Tips & tricks")
                            .bold()
                            .font(.title)
                            .foregroundColor(textColor)
                    
                            Text("The XNOR operation returns TRUE only if the inputs are equals. For example if you give as input TRUE and FALSE the return value will be FALSE.")
                            .font(.system(size: fontSize))
                            .foregroundColor(textColor)
                            .frame(width: textWidth / 2, height: .infinity, alignment: .center)
                        }
                    }
                }
                
                Text("This page features three logical circuits.\n1. Look at the outputs of the circuits.\n2. Bring particular attention to the two circuits on the top side, they will always share the output, why?\n3. Try changing the values of the inputs. What happens to the outputs?")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .leading)
                
                HStack {
                    Text("var A = " + String(inputA))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                                        
                    Button(action: {
                        inputA = !inputA
                    })
                    {
                        Text("Change the value of A")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var B = " + String(inputB))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputB = !inputB
                    })
                    {
                        Text("Change the value of B")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                }
                
                HStack {
                    Text("var E = " + String(inputE))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputE = !inputE
                    })
                    {
                        Text("Change the value of E")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                    
                    Text("var F = " + String(inputF))
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                    
                    Button(action: {
                        inputF = !inputF
                    })
                    {
                        Text("Change the value of F")
                            .font(.system(size: fontSize))
                    }
                    .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                    .tint(textColor)
                    .background(buttonColor)
                    .cornerRadius(buttonCornerRadius)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "XNORconAB.png")!)
                    
                    Text(String(inputA == inputB))
                    .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                    
                    Spacer().frame(width: spacerDimension)
                    
                    Image(uiImage: UIImage(named: "Circuito9.png")!)
                    
                    Text(String((inputA == inputB)))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "Circuito10.png")!)
                    Text(String(inputE && !inputF))
                        .font(.system(size: fontSize*1.5))
                    .foregroundColor(outputTextColor)
                }
                
            case 9:
                ZStack {
                    Color.clear
                        .frame(width: textWidth * 2, height: 250, alignment: .center)
                        .cornerRadius(tipsBoxCornerRradius)
                        .border(tipsBoxColor)
                    
                    VStack {
                Text("The end")
                    .bold()
                    .font(.largeTitle)
                    .foregroundColor(textColor)
                
                Text("The playground ends here, I really hope that you liked my playground and the idea behind it, winning a WWDC scholarship would be the crowning of my three years long journey at the Apple Developer Academy. Who knows, maybe it taught you something about boolean algebra too 😆.\nI also enjoyed it because it brought to my mind many memories of college days and it was also my first project implemented using swiftUI.\nLastly I give you my greetings, Thank you for your attention.")
                .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .center)
                                
                Text("- Michele Impinto")
                    .italic()
                    .font(.system(size: fontSize))
                .foregroundColor(textColor)
                .frame(width: textWidth, height: .infinity, alignment: .trailing)
                    }
                }
                
                Spacer().frame(height: spacerDimension)
                
            default:
                Spacer().frame(width: 0, height: 0, alignment: .center)
            }
                        
            HStack {
            if currPage > 0 {
                Button(action: {
                    currPage -= 1
                }){
                    Text("Go back")
                        .font(.system(size: fontSize))
                        .foregroundColor(textColor)
                }
                .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                .tint(textColor)
                .background(buttonColor)
                .cornerRadius(buttonCornerRadius)
            }
            
            if currPage < 9 {
                Button(action: {
                    if currPage <= 8 {
                        currPage += 1
                    }
                }){
                    Text("Go to the next page")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                }
                .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                .tint(textColor)
                .background(buttonColor)
                .cornerRadius(buttonCornerRadius)
            }
            else {
                Button(action: {
                    currPage = 0
                }){
                    Text("Restart")
                    .font(.system(size: fontSize))
                    .foregroundColor(textColor)
                }
                .frame(width: buttonWidth, height: buttonHeight, alignment: .center)
                .tint(textColor)
                .background(buttonColor)
                .cornerRadius(buttonCornerRadius)
            }
            }
        }
    }
}
