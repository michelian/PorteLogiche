import SwiftUI


@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ZStack {
                Color.white.ignoresSafeArea()
                Introduction()
            }
        }
    }
}
